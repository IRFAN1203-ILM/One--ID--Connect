
# One ID Connect (Starter)

This is a basic starter for a real-time web app using ASP.NET Core (.NET 6) and SignalR.  
It allows users to chat in real-time using a simple front-end.

## How to Run

1. Open the folder in Visual Studio
2. Make sure you have .NET 6 SDK installed
3. Run the project (`dotnet run`)
4. Open `http://localhost:5000` to test chat

## Technologies Used

- ASP.NET Core (.NET 6)
- SignalR
- HTML/JavaScript
